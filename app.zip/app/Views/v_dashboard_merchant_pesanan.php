<?php
/**
 * VIEW: Dashboard Merchant - Daftar Pesanan Dengan Verifikasi Pembayaran
 * Path: app/Views/v_dashboard_merchant_pesanan.php
 * 
 * Fitur:
 * 1. Tampilkan daftar pesanan dari tempat kuliner merchant
 * 2. Filter berdasarkan status pembayaran
 * 3. Tombol "Lihat Bukti" untuk melihat foto bukti transfer
 * 4. Tombol "Setujui" dan "Tolak" untuk verifikasi pembayaran
 * 5. Status badge dengan warna informatif
 */
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard Merchant - Verifikasi Pembayaran</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <style>
        body {
            background-color: #f5f7fa;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }

        .navbar-custom {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
        }

        .navbar-custom .navbar-brand {
            font-weight: 700;
            font-size: 24px;
            color: white !important;
        }

        .navbar-custom .nav-link {
            color: rgba(255, 255, 255, 0.9) !important;
            font-weight: 500;
            margin-left: 20px;
            transition: color 0.3s;
        }

        .navbar-custom .nav-link:hover {
            color: white !important;
        }

        .container-dashboard {
            margin-top: 30px;
            margin-bottom: 30px;
        }

        .header-section {
            background: white;
            border-radius: 12px;
            padding: 25px;
            margin-bottom: 30px;
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.08);
            border-left: 4px solid #667eea;
        }

        .header-section h2 {
            color: #667eea;
            font-weight: 700;
            margin-bottom: 15px;
        }

        .filter-section {
            background: white;
            border-radius: 12px;
            padding: 20px;
            margin-bottom: 25px;
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.08);
        }

        .filter-section .form-label {
            font-weight: 600;
            color: #495057;
            margin-bottom: 8px;
        }

        .filter-btn {
            padding: 10px 20px;
            border-radius: 6px;
            font-weight: 600;
            border: none;
            cursor: pointer;
            transition: all 0.3s;
        }

        .filter-btn.active {
            background-color: #667eea;
            color: white;
        }

        .filter-btn.inactive {
            background-color: #e9ecef;
            color: #495057;
        }

        .filter-btn:hover:not(.inactive) {
            background-color: #667eea;
            color: white;
        }

        .table-container {
            background: white;
            border-radius: 12px;
            overflow: hidden;
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.08);
            margin-bottom: 30px;
        }

        .table-custom {
            margin-bottom: 0;
            font-size: 14px;
        }

        .table-custom thead {
            background-color: #f8f9fa;
            border-bottom: 2px solid #dee2e6;
        }

        .table-custom thead th {
            font-weight: 700;
            color: #495057;
            padding: 15px;
            vertical-align: middle;
            text-transform: uppercase;
            font-size: 12px;
        }

        .table-custom tbody td {
            padding: 15px;
            vertical-align: middle;
            border-bottom: 1px solid #dee2e6;
        }

        .table-custom tbody tr:hover {
            background-color: #f8f9fa;
        }

        .status-badge {
            display: inline-block;
            padding: 6px 12px;
            border-radius: 20px;
            font-weight: 600;
            font-size: 11px;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }

        .status-pending-verification {
            background-color: #fff3cd;
            color: #856404;
        }

        .status-pending-confirmation {
            background-color: #cfe2ff;
            color: #084298;
        }

        .status-paid {
            background-color: #d1e7dd;
            color: #0a3622;
        }

        .status-rejected {
            background-color: #f8d7da;
            color: #842029;
        }

        .status-completed {
            background-color: #badbcc;
            color: #0f5132;
        }

        .btn-action {
            padding: 6px 12px;
            font-size: 12px;
            font-weight: 600;
            border-radius: 6px;
            cursor: pointer;
            transition: all 0.3s;
            border: none;
            margin: 2px;
        }

        .btn-view {
            background-color: #17a2b8;
            color: white;
        }

        .btn-view:hover {
            background-color: #138496;
            color: white;
        }

        .btn-approve {
            background-color: #28a745;
            color: white;
        }

        .btn-approve:hover {
            background-color: #218838;
            color: white;
        }

        .btn-reject {
            background-color: #dc3545;
            color: white;
        }

        .btn-reject:hover {
            background-color: #c82333;
            color: white;
        }

        .empty-state {
            text-align: center;
            padding: 60px 20px;
            background: white;
            border-radius: 12px;
        }

        .empty-state-icon {
            font-size: 64px;
            color: #dee2e6;
            margin-bottom: 20px;
        }

        .empty-state-title {
            font-size: 24px;
            font-weight: 700;
            color: #495057;
            margin-bottom: 10px;
        }

        .empty-state-desc {
            font-size: 16px;
            color: #6c757d;
        }

        /* MODAL UNTUK LIHAT BUKTI PEMBAYARAN */
        .modal-custom {
            display: none;
            position: fixed;
            z-index: 1000;
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0, 0, 0, 0.5);
            animation: fadeIn 0.3s ease;
        }

        .modal-custom.show {
            display: block;
        }

        @keyframes fadeIn {
            from { opacity: 0; }
            to { opacity: 1; }
        }

        .modal-custom-content {
            background-color: white;
            margin: 5% auto;
            padding: 30px;
            border-radius: 12px;
            width: 90%;
            max-width: 600px;
            box-shadow: 0 10px 40px rgba(0, 0, 0, 0.3);
            animation: slideDown 0.3s ease;
        }

        @keyframes slideDown {
            from {
                transform: translateY(-50px);
                opacity: 0;
            }
            to {
                transform: translateY(0);
                opacity: 1;
            }
        }

        .modal-header-custom {
            border-bottom: 2px solid #f0f0f0;
            padding-bottom: 15px;
            margin-bottom: 20px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .modal-header-custom h5 {
            margin: 0;
            color: #667eea;
            font-weight: 700;
        }

        .close-btn {
            background: none;
            border: none;
            font-size: 24px;
            cursor: pointer;
            color: #6c757d;
            transition: color 0.3s;
        }

        .close-btn:hover {
            color: #495057;
        }

        .modal-body-custom {
            text-align: center;
        }

        .modal-image {
            max-width: 100%;
            max-height: 500px;
            border-radius: 8px;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
            margin-bottom: 20px;
        }

        .modal-info {
            background-color: #f8f9fa;
            padding: 15px;
            border-radius: 6px;
            margin-bottom: 20px;
            text-align: left;
        }

        .modal-info-row {
            display: flex;
            justify-content: space-between;
            padding: 8px 0;
            border-bottom: 1px solid #e9ecef;
        }

        .modal-info-row:last-child {
            border-bottom: none;
        }

        .modal-info-label {
            font-weight: 600;
            color: #495057;
        }

        .modal-info-value {
            color: #212529;
        }

        .modal-action {
            display: flex;
            gap: 10px;
            justify-content: center;
            margin-top: 20px;
        }

        .modal-action button {
            padding: 12px 25px;
            font-weight: 600;
            border-radius: 6px;
            border: none;
            cursor: pointer;
            transition: all 0.3s;
        }

        .loading-spinner {
            display: none;
            text-align: center;
        }

        .spinner {
            border: 4px solid #f3f3f3;
            border-top: 4px solid #667eea;
            border-radius: 50%;
            width: 40px;
            height: 40px;
            animation: spin 1s linear infinite;
            margin: 0 auto;
        }

        @keyframes spin {
            0% { transform: rotate(0deg); }
            100% { transform: rotate(360deg); }
        }

        .no-data-message {
            text-align: center;
            padding: 40px;
            color: #6c757d;
            font-size: 16px;
        }

        .badge-count {
            position: absolute;
            top: -8px;
            right: -8px;
            background-color: #dc3545;
            color: white;
            border-radius: 50%;
            width: 24px;
            height: 24px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: 700;
            font-size: 12px;
        }

        .filter-badge-container {
            position: relative;
            display: inline-block;
        }
    </style>
</head>
<body>
<!-- NAVBAR -->
<nav class="navbar navbar-expand-lg navbar-custom">
    <div class="container-fluid">
        <span class="navbar-brand">
            <i class="fas fa-store"></i> Dashboard Merchant
        </span>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav ms-auto">
                <li class="nav-item">
                    <a class="nav-link" href="/home">
                        <i class="fas fa-home"></i> Beranda
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="/logout">
                        <i class="fas fa-sign-out-alt"></i> Logout
                    </a>
                </li>
            </ul>
        </div>
    </div>
</nav>

<!-- MAIN CONTENT -->
<div class="container-dashboard">
    <div class="container">
        <!-- HEADER -->
        <div class="header-section">
            <h2>
                <i class="fas fa-list-check"></i> Verifikasi Pembayaran Pesanan
            </h2>
            <p class="text-muted" style="margin-top: 10px;">
                Kelola dan verifikasi bukti pembayaran transfer bank dari pelanggan Anda
            </p>
        </div>

        <!-- FILTER SECTION -->
        <div class="filter-section">
            <div class="row">
                <div class="col-md-6">
                    <label class="form-label">Filter Berdasarkan Status:</label>
                    <div style="display: flex; gap: 10px; flex-wrap: wrap;">
                        <button class="filter-btn active" onclick="filterTable('all')">
                            📋 Semua
                        </button>
                        <button class="filter-btn filter-badge-container" onclick="filterTable('menunggu_verifikasi')">
                            ⏳ Menunggu Verifikasi
                            <?php if (isset($countPendingVerification) && $countPendingVerification > 0): ?>
                                <span class="badge-count"><?= $countPendingVerification ?></span>
                            <?php endif; ?>
                        </button>
                        <button class="filter-btn" onclick="filterTable('sudah_dibayar')">
                            ✅ Sudah Dibayar
                        </button>
                        <button class="filter-btn" onclick="filterTable('pembayaran_ditolak')">
                            ❌ Pembayaran Ditolak
                        </button>
                    </div>
                </div>
            </div>
        </div>

        <!-- TABLE PESANAN -->
        <div class="table-container">
            <?php if (!empty($pesanan)): ?>
            <table class="table table-custom" id="tableOrders">
                <thead>
                    <tr>
                        <th>ID Pesanan</th>
                        <th>Nama Pemesan</th>
                        <th>Tempat Kuliner</th>
                        <th>Total Tagihan</th>
                        <th>Status Pembayaran</th>
                        <th>Tanggal Pesan</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($pesanan as $item): ?>
                    <tr class="order-row" data-status="<?= strtolower(str_replace(' ', '_', $item['status_pesanan'])) ?>">
                        <td>
                            <strong>#<?= $item['id_pesanan'] ?></strong>
                        </td>
                        <td>
                            <strong><?= esc($item['nama_pemesan']) ?></strong>
                            <br>
                            <small class="text-muted"><?= esc($item['nomor_hp']) ?></small>
                        </td>
                        <td>
                            <?= esc($item['nama_tempat']) ?>
                            <br>
                            <small class="text-muted"><?= esc($item['kategori']) ?></small>
                        </td>
                        <td>
                            <strong style="color: #ff6600;">
                                Rp <?= number_format($item['harga_perkiraan'], 0, ',', '.') ?>
                            </strong>
                        </td>
                        <td>
                            <span class="status-badge status-<?= strtolower(str_replace(' ', '_', $item['status_pesanan'])) ?>">
                                <?= $item['status_pesanan'] ?>
                            </span>
                        </td>
                        <td>
                            <small><?= date('d-m-Y H:i', strtotime($item['tanggal_pesan'])) ?></small>
                        </td>
                        <td>
                            <?php if (strtolower($item['status_pesanan']) === 'menunggu verifikasi' && !empty($item['bukti_pembayaran'])): ?>
                                <!-- Tombol untuk melihat bukti -->
                                <button class="btn-action btn-view" onclick="viewBukti('<?= $item['id_pesanan'] ?>', '<?= esc($item['bukti_pembayaran']) ?>', '<?= esc($item['nama_pemesan']) ?>', '<?= number_format($item['harga_perkiraan'], 0, ',', '.') ?>')">
                                    <i class="fas fa-eye"></i> Lihat Bukti
                                </button>
                                <br>
                                <!-- Tombol Setujui & Tolak -->
                                <button class="btn-action btn-approve" onclick="approvePayment(<?= $item['id_pesanan'] ?>)">
                                    <i class="fas fa-check"></i> Setujui
                                </button>
                                <button class="btn-action btn-reject" onclick="rejectPayment(<?= $item['id_pesanan'] ?>)">
                                    <i class="fas fa-times"></i> Tolak
                                </button>
                            <?php elseif (strtolower($item['status_pesanan']) === 'menunggu konfirmasi'): ?>
                                <span class="text-muted" style="font-size: 12px;">
                                    ⏳ Menunggu pelanggan upload bukti
                                </span>
                            <?php elseif (strtolower($item['status_pesanan']) === 'sudah dibayar'): ?>
                                <span class="text-success" style="font-size: 12px;">
                                    ✅ Sudah diverifikasi
                                </span>
                            <?php elseif (strtolower($item['status_pesanan']) === 'pembayaran ditolak'): ?>
                                <span class="text-danger" style="font-size: 12px;">
                                    ❌ Ditolak - Menunggu re-upload
                                </span>
                            <?php endif; ?>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
            <?php else: ?>
                <div class="empty-state">
                    <div class="empty-state-icon">📋</div>
                    <div class="empty-state-title">Tidak Ada Pesanan</div>
                    <div class="empty-state-desc">Saat ini belum ada pesanan dari pelanggan Anda</div>
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>

<!-- MODAL: LIHAT BUKTI PEMBAYARAN -->
<div class="modal-custom" id="modalBukti">
    <div class="modal-custom-content">
        <div class="modal-header-custom">
            <h5>📸 Bukti Pembayaran Transfer Bank</h5>
            <button class="close-btn" onclick="closeBuktiModal()">×</button>
        </div>
        
        <div class="modal-body-custom">
            <!-- Loading spinner -->
            <div class="loading-spinner" id="loadingBukti">
                <div class="spinner"></div>
                <p>Memuat gambar...</p>
            </div>

            <!-- Image -->
            <img id="buktiImage" class="modal-image" src="" alt="Bukti Pembayaran" style="display: none;">

            <!-- Info -->
            <div class="modal-info" id="buktiInfo" style="display: none;">
                <div class="modal-info-row">
                    <span class="modal-info-label">Nama Pemesan:</span>
                    <span class="modal-info-value" id="buktiNama">-</span>
                </div>
                <div class="modal-info-row">
                    <span class="modal-info-label">Total Tagihan:</span>
                    <span class="modal-info-value" id="buktiTotal">-</span>
                </div>
                <div class="modal-info-row">
                    <span class="modal-info-label">Tanggal Upload:</span>
                    <span class="modal-info-value" id="buktiTanggal">-</span>
                </div>
            </div>

            <!-- Action Buttons -->
            <div class="modal-action" id="buktiAction" style="display: none;">
                <button class="btn-approve" onclick="approvePaymentFromModal()">
                    <i class="fas fa-check"></i> Setujui Pembayaran
                </button>
                <button class="btn-reject" onclick="rejectPaymentFromModal()">
                    <i class="fas fa-times"></i> Tolak Pembayaran
                </button>
                <button style="background-color: #6c757d; color: white;" onclick="closeBuktiModal()">
                    Tutup
                </button>
            </div>
        </div>
    </div>
</div>

<!-- SCRIPT -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script>
let currentPesananId = null;

// Fungsi filter table berdasarkan status
function filterTable(status) {
    const rows = document.querySelectorAll('.order-row');
    let visibleCount = 0;

    rows.forEach(row => {
        const rowStatus = row.getAttribute('data-status');
        
        if (status === 'all' || rowStatus === status) {
            row.style.display = '';
            visibleCount++;
        } else {
            row.style.display = 'none';
        }
    });

    // Update button active state
    document.querySelectorAll('.filter-btn').forEach(btn => {
        btn.classList.remove('active');
    });
    event.target.classList.add('active');

    // Tampilkan pesan jika tidak ada data
    const table = document.getElementById('tableOrders');
    if (visibleCount === 0 && table) {
        if (!document.getElementById('noDataMsg')) {
            const noDataRow = document.createElement('tr');
            noDataRow.id = 'noDataMsg';
            noDataRow.innerHTML = '<td colspan="7" class="no-data-message">Tidak ada pesanan dengan status ini</td>';
            table.querySelector('tbody').appendChild(noDataRow);
        }
    } else if (document.getElementById('noDataMsg')) {
        document.getElementById('noDataMsg').remove();
    }
}

// Fungsi untuk membuka modal lihat bukti
function viewBukti(pesananId, buktiFile, namaPemesan, totalTagihan) {
    currentPesananId = pesananId;
    
    const modal = document.getElementById('modalBukti');
    const loadingSpinner = document.getElementById('loadingBukti');
    const buktiImage = document.getElementById('buktiImage');
    const buktiInfo = document.getElementById('buktiInfo');
    const buktiAction = document.getElementById('buktiAction');

    // Tampilkan loading
    loadingSpinner.style.display = 'block';
    buktiImage.style.display = 'none';
    buktiInfo.style.display = 'none';
    buktiAction.style.display = 'none';

    // Set path ke gambar
    const imagePath = '/uploads/bukti_bayar/' + encodeURIComponent(buktiFile);
    
    // Load image
    const img = new Image();
    img.onload = function() {
        buktiImage.src = imagePath;
        buktiImage.style.display = 'block';
        document.getElementById('buktiNama').textContent = namaPemesan;
        document.getElementById('buktiTotal').textContent = 'Rp ' + totalTagihan;
        document.getElementById('buktiTanggal').textContent = new Date().toLocaleDateString('id-ID');
        
        loadingSpinner.style.display = 'none';
        buktiInfo.style.display = 'block';
        buktiAction.style.display = 'flex';
    };
    img.onerror = function() {
        loadingSpinner.style.display = 'none';
        alert('❌ Gagal memuat gambar bukti pembayaran');
    };
    img.src = imagePath;

    // Tampilkan modal
    modal.classList.add('show');
}

// Fungsi tutup modal
function closeBuktiModal() {
    document.getElementById('modalBukti').classList.remove('show');
    currentPesananId = null;
}

// Fungsi approve payment (dari tombol di table)
function approvePayment(pesananId) {
    if (!confirm('Apakah Anda yakin ingin menyetujui pembayaran ini?')) {
        return;
    }

    fetch(`/pesanan/approvePayment/${pesananId}`, {
        method: 'POST',
        headers: {
            'X-Requested-With': 'XMLHttpRequest',
            'Content-Type': 'application/json'
        }
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            alert('✅ ' + data.message);
            window.location.reload();
        } else {
            alert('❌ Error: ' + data.message);
        }
    })
    .catch(error => {
        alert('❌ Terjadi kesalahan: ' + error);
    });
}

// Fungsi reject payment (dari tombol di table)
function rejectPayment(pesananId) {
    if (!confirm('Apakah Anda yakin ingin menolak pembayaran ini? Pelanggan dapat mengunggah ulang bukti.')) {
        return;
    }

    fetch(`/pesanan/rejectPayment/${pesananId}`, {
        method: 'POST',
        headers: {
            'X-Requested-With': 'XMLHttpRequest',
            'Content-Type': 'application/json'
        }
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            alert('✅ ' + data.message);
            window.location.reload();
        } else {
            alert('❌ Error: ' + data.message);
        }
    })
    .catch(error => {
        alert('❌ Terjadi kesalahan: ' + error);
    });
}

// Fungsi approve payment dari modal
function approvePaymentFromModal() {
    approvePayment(currentPesananId);
}

// Fungsi reject payment dari modal
function rejectPaymentFromModal() {
    rejectPayment(currentPesananId);
}

// Close modal ketika klik di luar modal
window.onclick = function(event) {
    const modal = document.getElementById('modalBukti');
    if (event.target === modal) {
        closeBuktiModal();
    }
}
</script>
</body>
</html>
