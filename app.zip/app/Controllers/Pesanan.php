<?php

namespace App\Controllers;

use App\Models\KulinerModel;
use App\Models\MenuModel;
use App\Models\PesananDetailModel;
use App\Models\PesananModel;
use App\Services\OrderService;

class Pesanan extends BaseController
{
    public function simpan()
    {
        // Cek apakah user sudah login
        if (!session()->get('logged_in')) {
            return $this->response->setJSON([
                'success' => false,
                'message' => 'Silakan login terlebih dahulu'
            ]);
        }

        $model = new PesananModel();
        $menuModel = new MenuModel();
        $detailModel = new PesananDetailModel();

        $menuPesananRaw = $this->request->getPost('menu_pesanan');
        $menuItems = json_decode($menuPesananRaw, true);

        if (!is_array($menuItems) || empty($menuItems)) {
            return $this->response->setJSON([
                'success' => false,
                'message' => 'Menu pesanan tidak valid. Pastikan Anda menambahkan item menu terlebih dahulu.'
            ]);
        }

        $subtotal = 0;
        $totalQty = 0;

        foreach ($menuItems as $item) {
            if (!isset($item['name'], $item['price'], $item['quantity'])) {
                return $this->response->setJSON([
                    'success' => false,
                    'message' => 'Data menu pesanan tidak lengkap.'
                ]);
            }

            $price = (float) $item['price'];
            $qty = (int) $item['quantity'];

            if ($qty <= 0 || $price < 0) {
                return $this->response->setJSON([
                    'success' => false,
                    'message' => 'Jumlah dan harga item harus valid.'
                ]);
            }

            $subtotal += $price * $qty;
            $totalQty += $qty;
        }

        $serviceFee = (int) round($subtotal * 0.02);
        $tax = (int) round($subtotal * 0.10);
        $totalBayar = $subtotal + $serviceFee + $tax;

        // Ambil data dari form
        $data = [
            'id_tempat'          => $this->request->getPost('id_tempat'),
            'nama_tempat'        => $this->request->getPost('nama_tempat'),
            'kategori'           => $this->request->getPost('kategori'),
            'nama_pemesan'       => $this->request->getPost('nama_pemesan'),
            'nomor_hp'           => $this->request->getPost('nomor_hp'),
            'menu_pesanan'       => json_encode($menuItems, JSON_UNESCAPED_UNICODE),
            'jumlah'             => $totalQty,
            'harga_perkiraan'    => max(0, $totalBayar),
            'catatan'            => $this->request->getPost('catatan'),
            'metode_pembayaran'  => $this->request->getPost('metode_pembayaran'),
            'status_pesanan'     => 'Menunggu Konfirmasi',
            'tanggal_pesan'      => date('Y-m-d H:i:s'),
            'user_id'            => session()->get('id_user') ?? null,
        ];

        // Validasi input
        if (empty($data['nama_pemesan']) || empty($data['nomor_hp']) || empty($data['menu_pesanan']) || $totalQty <= 0 || $data['harga_perkiraan'] <= 0) {
            return $this->response->setJSON([
                'success' => false,
                'message' => 'Nama pemesan, nomor HP, dan menu tidak boleh kosong. Pastikan ada item pesanan dan total sudah dihitung.'
            ]);
        }

        try {
            // Insert data ke database
            $pesanan_id = $model->insert($data);

            if ($pesanan_id) {
                $kulinerId = (int) $data['id_tempat'];

                foreach ($menuItems as $item) {
                    $menuId = 0;

                    if (isset($item['id']) && is_numeric($item['id'])) {
                        $menuId = (int) $item['id'];
                    } elseif (! empty($data['id_tempat']) && isset($item['name'])) {
                        $menu = $menuModel->findByNameAndKuliner($item['name'], $kulinerId);
                        $menuId = $menu ? (int) $menu['id'] : 0;
                    }

                    $detailModel->insert([
                        'pesanan_id' => $pesanan_id,
                        'menu_id'    => $menuId,
                        'qty'        => (int) $item['quantity'],
                        'subtotal'   => (float) ($item['price'] * $item['quantity']),
                    ]);
                }
            }

            return $this->response->setJSON([
                'success' => true,
                'message' => 'Pesanan berhasil dibuat',
                'pesanan_id' => $pesanan_id
            ]);
        } catch (\Exception $e) {
            return $this->response->setJSON([
                'success' => false,
                'message' => 'Gagal menyimpan pesanan: ' . $e->getMessage()
            ]);
        }
    }

    /**
     * Menyelesaikan pesanan kuliner
     * @param int $id ID dari Pesanan
     */
    public function complete(int $id)
    {
        if (!session()->get('logged_in')) {
            return $this->response->setJSON([
                'success' => false,
                'message' => 'Silakan login terlebih dahulu'
            ]);
        }

        $model = new PesananModel();
        $service = new OrderService();

        $pesanan = $model->find($id);

        if (! $pesanan) {
            return $this->response->setJSON([
                'success' => false,
                'message' => 'Pesanan tidak ditemukan.'
            ])->setStatusCode(404);
        }

        if (strtolower($pesanan['status_pesanan']) === 'completed') {
            return $this->response->setJSON([
                'success' => false,
                'message' => 'Pesanan sudah selesai.'
            ]);
        }

        $statusUpdated = $model->update($id, ['status_pesanan' => 'completed']);
        $walletCredited = $service->processOrderCompletion($id);

        return $this->response->setJSON([
            'success' => (bool) $statusUpdated,
            'message' => $statusUpdated ? 'Pesanan telah diselesaikan.' : 'Gagal menyelesaikan pesanan.',
            'walletCredited' => $walletCredited,
        ]);
    }

    public function requestWithdrawal()
    {
        if (!session()->get('logged_in') || session()->get('role') !== 'merchant') {
            return $this->response->setJSON([
                'success' => false,
                'message' => 'Akses ditolak. Hanya merchant yang dapat mengajukan penarikan.'
            ])->setStatusCode(403);
        }

        $merchantId = session()->get('id') ?? session()->get('id_user');
        $jumlahTarik = (float) $this->request->getPost('jumlah_tarik');
        $bankData = [
            'bank_tujuan' => $this->request->getPost('bank_tujuan'),
            'nomor_rekening' => $this->request->getPost('nomor_rekening'),
            'nama_rekening' => $this->request->getPost('nama_rekening'),
        ];

        $service = new OrderService();
        $withdrawalId = $service->createWithdrawalRequest((int) $merchantId, $jumlahTarik, $bankData);

        if (! $withdrawalId) {
            return $this->response->setJSON([
                'success' => false,
                'message' => 'Saldo tidak mencukupi atau data penarikan tidak valid.'
            ])->setStatusCode(400);
        }

        return $this->response->setJSON([
            'success' => true,
            'message' => 'Permintaan penarikan berhasil diajukan.',
            'withdrawal_id' => $withdrawalId,
        ]);
    }

    /**
     * Menyetujui penarikan saldo merchant
     * @param int $id ID dari Withdrawal
     */
    public function approveWithdrawal(int $id)
    {
        if (!session()->get('logged_in') || session()->get('role') !== 'developer') {
            return $this->response->setJSON([
                'success' => false,
                'message' => 'Akses ditolak. Hanya developer yang bisa menyetujui penarikan.'
            ])->setStatusCode(403);
        }

        $service = new OrderService();
        $approved = $service->approveWithdrawal($id);

        return $this->response->setJSON([
            'success' => $approved,
            'message' => $approved ? 'Penarikan disetujui.' : 'Gagal menyetujui penarikan.'
        ]);
    }

    /**
     * Menolak penarikan saldo merchant
     * @param int $id ID dari Withdrawal
     */
    public function rejectWithdrawal(int $id)
    {
        if (!session()->get('logged_in') || session()->get('role') !== 'developer') {
            return $this->response->setJSON([
                'success' => false,
                'message' => 'Akses ditolak. Hanya developer yang bisa menolak penarikan.'
            ])->setStatusCode(403);
        }

        $service = new OrderService();
        $rejected = $service->rejectWithdrawal($id);

        return $this->response->setJSON([
            'success' => $rejected,
            'message' => $rejected ? 'Penarikan ditolak.' : 'Gagal menolak penarikan.'
        ]);
    }

    public function daftar()
    {
        // Proteksi halaman
        if (!session()->get('logged_in')) {
            return redirect()->to('/login')->with('error', 'Silakan login terlebih dahulu.');
        }

        $model = new PesananModel();
        $data['pesanan'] = $model->findAll();

        return view('v_daftar_pesanan', $data);
    }

    /**
     * Menghapus data pesanan kuliner
     * @param int $id ID dari Pesanan
     */
    public function hapus(int $id)
    {
        if (!session()->get('logged_in')) {
            return redirect()->to('/login')->with('error', 'Silakan login terlebih dahulu.');
        }

        $model = new PesananModel();
        $model->delete($id);

        return redirect()->to('/pesanan/daftar')->with('success', 'Pesanan berhasil dihapus');
    }

    /**
     * =====================================================================
     * FITUR PEMBAYARAN TRANSFER BANK MANUAL - METHODS BARU
     * =====================================================================
     */

    /**
     * Upload bukti pembayaran transfer bank
     * 
     * Fitur keamanan:
     * 1. Validasi user login
     * 2. Validasi eksistensi pesanan
     * 3. Validasi ownership pesanan
     * 4. Validasi tipe file (hanya image)
     * 5. Validasi ukuran file (max 2MB)
     * 6. Enkripsi nama file menggunakan getRandomName()
     * 7. Simpan ke direktori aman: public/uploads/bukti_bayar/
     * 8. Update database dengan nama file dan status
     * 
     * @param int $pesanan_id ID Pesanan
     * @return JSON
     */
    public function uploadBukti(int $pesanan_id)
    {
        // ===== VALIDASI 1: CEK LOGIN =====
        if (!session()->get('logged_in')) {
            return $this->response->setJSON([
                'success' => false,
                'message' => 'Silakan login terlebih dahulu'
            ])->setStatusCode(401);
        }

        // ===== VALIDASI 2: CEK PESANAN EXIST =====
        $model = new PesananModel();
        $pesanan = $model->find($pesanan_id);

        if (!$pesanan) {
            return $this->response->setJSON([
                'success' => false,
                'message' => 'Pesanan tidak ditemukan'
            ])->setStatusCode(404);
        }

        // ===== VALIDASI 3: CEK OWNERSHIP PESANAN =====
        $currentUserId = session()->get('id_user') ?? session()->get('id');
        if ((int) $pesanan['user_id'] !== (int) $currentUserId) {
            return $this->response->setJSON([
                'success' => false,
                'message' => 'Anda tidak memiliki akses untuk mengupload bukti pesanan ini'
            ])->setStatusCode(403);
        }

        // ===== VALIDASI 4: CEK FILE UPLOAD =====
        $file = $this->request->getFile('bukti_pembayaran');

        if (!$file || $file->getError() !== UPLOAD_ERR_OK) {
            return $this->response->setJSON([
                'success' => false,
                'message' => 'File tidak ditemukan atau terjadi error saat upload'
            ])->setStatusCode(400);
        }

        // ===== VALIDASI 5: CEK TIPE FILE (HANYA IMAGE) =====
        $allowedMimes = ['image/png', 'image/jpeg', 'image/jpg'];
        if (!in_array($file->getMimeType(), $allowedMimes)) {
            return $this->response->setJSON([
                'success' => false,
                'message' => 'Format file tidak didukung. Hanya PNG, JPG, dan JPEG yang diizinkan'
            ])->setStatusCode(400);
        }

        // ===== VALIDASI 6: CEK UKURAN FILE (MAX 2MB = 2097152 BYTES) =====
        $maxSize = 2097152; // 2 MB in bytes
        if ($file->getSize() > $maxSize) {
            return $this->response->setJSON([
                'success' => false,
                'message' => 'Ukuran file terlalu besar! Maksimal 2 MB'
            ])->setStatusCode(400);
        }

        // ===== VALIDASI 7: PINDAHKAN & ENKRIPSI NAMA FILE =====
        try {
            $uploadPath = ROOTPATH . 'public/uploads/bukti_bayar';

            // Pastikan direktori exists
            if (!is_dir($uploadPath)) {
                mkdir($uploadPath, 0755, true);
            }

            // Gunakan getRandomName() untuk enkripsi nama file
            $namaFileAcak = $file->getRandomName();

            // Move file dengan nama terenkripsi
            $file->move($uploadPath, $namaFileAcak);

            // ===== VALIDASI 8: UPDATE DATABASE =====
            $updateData = [
                'bukti_pembayaran' => $namaFileAcak,
                'status_pesanan' => 'Menunggu Verifikasi'
            ];

            $updated = $model->update($pesanan_id, $updateData);

            if ($updated) {
                return $this->response->setJSON([
                    'success' => true,
                    'message' => 'Bukti pembayaran berhasil diunggah! Status pesanan menjadi Menunggu Verifikasi'
                ]);
            } else {
                // Jika update gagal, hapus file yang sudah diupload
                @unlink($uploadPath . DIRECTORY_SEPARATOR . $namaFileAcak);
                return $this->response->setJSON([
                    'success' => false,
                    'message' => 'Gagal menyimpan data bukti pembayaran ke database'
                ])->setStatusCode(500);
            }

        } catch (\Exception $e) {
            return $this->response->setJSON([
                'success' => false,
                'message' => 'Terjadi kesalahan server: ' . $e->getMessage()
            ])->setStatusCode(500);
        }
    }

    /**
     * Detail pesanan (menampilkan halaman v_detail_pesanan)
     * 
     * @param int $pesanan_id ID Pesanan
     */
    public function detail(int $pesanan_id)
    {
        if (!session()->get('logged_in')) {
            return redirect()->to('/login')->with('error', 'Silakan login terlebih dahulu.');
        }

        $model = new PesananModel();
        $pesanan = $model->find($pesanan_id);

        if (!$pesanan) {
            return redirect()->to('/home')->with('error', 'Pesanan tidak ditemukan.');
        }

        $currentUserId = session()->get('id_user') ?? session()->get('id');
        if ((int) $pesanan['user_id'] !== (int) $currentUserId) {
            return redirect()->to('/home')->with('error', 'Anda tidak memiliki akses ke pesanan ini.');
        }

        $data['pesanan'] = $pesanan;
        return view('v_detail_pesanan', $data);
    }

    /**
     * Menyetujui pembayaran transfer bank (aksi merchant)
     * 
     * @param int $pesanan_id ID Pesanan
     */
    public function approvePayment(int $pesanan_id)
    {
        // ===== VALIDASI: CEK MERCHANT LOGIN =====
        if (!session()->get('logged_in')) {
            return $this->response->setJSON([
                'success' => false,
                'message' => 'Silakan login terlebih dahulu'
            ])->setStatusCode(401);
        }

        // Cek apakah user adalah merchant
        $userRole = session()->get('role');
        if ($userRole !== 'merchant') {
            return $this->response->setJSON([
                'success' => false,
                'message' => 'Hanya merchant yang dapat menyetujui pembayaran'
            ])->setStatusCode(403);
        }

        $model = new PesananModel();
        $pesanan = $model->find($pesanan_id);

        if (!$pesanan) {
            return $this->response->setJSON([
                'success' => false,
                'message' => 'Pesanan tidak ditemukan'
            ])->setStatusCode(404);
        }

        // Cek apakah status pesanan adalah 'Menunggu Verifikasi'
        if (strtolower($pesanan['status_pesanan']) !== 'menunggu verifikasi') {
            return $this->response->setJSON([
                'success' => false,
                'message' => 'Pesanan ini tidak dalam status Menunggu Verifikasi'
            ])->setStatusCode(400);
        }

        // Update status menjadi 'Sudah Dibayar'
        $updated = $model->update($pesanan_id, [
            'status_pesanan' => 'Sudah Dibayar'
        ]);

        if ($updated) {
            return $this->response->setJSON([
                'success' => true,
                'message' => 'Pembayaran telah disetujui. Status pesanan berubah menjadi Sudah Dibayar'
            ]);
        } else {
            return $this->response->setJSON([
                'success' => false,
                'message' => 'Gagal menyetujui pembayaran'
            ])->setStatusCode(500);
        }
    }

    /**
     * Menolak pembayaran transfer bank (aksi merchant)
     * 
     * @param int $pesanan_id ID Pesanan
     */
    public function rejectPayment(int $pesanan_id)
    {
        // ===== VALIDASI: CEK MERCHANT LOGIN =====
        if (!session()->get('logged_in')) {
            return $this->response->setJSON([
                'success' => false,
                'message' => 'Silakan login terlebih dahulu'
            ])->setStatusCode(401);
        }

        // Cek apakah user adalah merchant
        $userRole = session()->get('role');
        if ($userRole !== 'merchant') {
            return $this->response->setJSON([
                'success' => false,
                'message' => 'Hanya merchant yang dapat menolak pembayaran'
            ])->setStatusCode(403);
        }

        $model = new PesananModel();
        $pesanan = $model->find($pesanan_id);

        if (!$pesanan) {
            return $this->response->setJSON([
                'success' => false,
                'message' => 'Pesanan tidak ditemukan'
            ])->setStatusCode(404);
        }

        // Cek apakah status pesanan adalah 'Menunggu Verifikasi'
        if (strtolower($pesanan['status_pesanan']) !== 'menunggu verifikasi') {
            return $this->response->setJSON([
                'success' => false,
                'message' => 'Pesanan ini tidak dalam status Menunggu Verifikasi'
            ])->setStatusCode(400);
        }

        // Update status menjadi 'Pembayaran Ditolak'
        $updated = $model->update($pesanan_id, [
            'status_pesanan' => 'Pembayaran Ditolak'
        ]);

        if ($updated) {
            return $this->response->setJSON([
                'success' => true,
                'message' => 'Pembayaran telah ditolak. Pelanggan dapat mengunggah ulang bukti pembayaran'
            ]);
        } else {
            return $this->response->setJSON([
                'success' => false,
                'message' => 'Gagal menolak pembayaran'
            ])->setStatusCode(500);
        }
    }

    /**
     * Dashboard Merchant: Menampilkan daftar pesanan untuk verifikasi pembayaran
     * Hanya untuk merchant yang sudah memiliki tempat kuliner
     */
    public function dashboardMerchant()
    {
        // ===== VALIDASI: CEK MERCHANT LOGIN =====
        if (!session()->get('logged_in')) {
            return redirect()->to('/login')->with('error', 'Silakan login terlebih dahulu.');
        }

        $userRole = session()->get('role');
        if ($userRole !== 'merchant') {
            return redirect()->to('/home')->with('error', 'Hanya merchant yang dapat mengakses dashboard ini.');
        }

        $model = new PesananModel();
        
        // Ambil semua pesanan yang metodenya transfer bank
        // (Atau semua pesanan jika Anda ingin menampilkan semua)
        $pesanan = $model->where('metode_pembayaran', 'Transfer Bank')
                        ->orderBy('tanggal_pesan', 'DESC')
                        ->findAll();

        // Hitung jumlah pesanan dengan status 'Menunggu Verifikasi'
        $countPendingVerification = 0;
        foreach ($pesanan as $p) {
            if (strtolower($p['status_pesanan']) === 'menunggu verifikasi') {
                $countPendingVerification++;
            }
        }

        $data['pesanan'] = $pesanan;
        $data['countPendingVerification'] = $countPendingVerification;

        return view('v_dashboard_merchant_pesanan', $data);
    }

    /**
     * Menampilkan halaman struk pembayaran
     * Halaman ini ditampilkan ketika status pesanan = 'Sudah Dibayar'
     * 
     * @param int $pesanan_id ID Pesanan
     */
    public function struk(int $pesanan_id)
    {
        // ===== VALIDASI: CEK LOGIN =====
        if (!session()->get('logged_in')) {
            return redirect()->to('/login')->with('error', 'Silakan login terlebih dahulu.');
        }

        $model = new PesananModel();
        $pesanan = $model->find($pesanan_id);

        if (!$pesanan) {
            return redirect()->to('/home')->with('error', 'Pesanan tidak ditemukan.');
        }

        // ===== VALIDASI: CEK OWNERSHIP =====
        $currentUserId = session()->get('id_user') ?? session()->get('id');
        if ((int) $pesanan['user_id'] !== (int) $currentUserId) {
            return redirect()->to('/home')->with('error', 'Anda tidak memiliki akses ke struk ini.');
        }

        // ===== VALIDASI: CEK STATUS =====
        $statusLower = strtolower($pesanan['status_pesanan']);
        if ($statusLower !== 'sudah dibayar') {
            return redirect()->to('/pesanan/detail/' . $pesanan_id)->with('error', 'Struk hanya tersedia untuk pesanan yang sudah diverifikasi.');
        }

        $data['pesanan'] = $pesanan;
        return view('v_struk_pembayaran', $data);
    }

    /**
     * Generate PDF Struk Pembayaran
     * 
     * @param int $pesanan_id ID Pesanan
     */
    public function strukPDF(int $pesanan_id)
    {
        // ===== VALIDASI: CEK LOGIN =====
        if (!session()->get('logged_in')) {
            return redirect()->to('/login')->with('error', 'Silakan login terlebih dahulu.');
        }

        $model = new PesananModel();
        $pesanan = $model->find($pesanan_id);

        if (!$pesanan) {
            return redirect()->to('/home')->with('error', 'Pesanan tidak ditemukan.');
        }

        // ===== VALIDASI: CEK OWNERSHIP =====
        $currentUserId = session()->get('id_user') ?? session()->get('id');
        if ((int) $pesanan['user_id'] !== (int) $currentUserId) {
            return redirect()->to('/home')->with('error', 'Anda tidak memiliki akses ke struk ini.');
        }

        // ===== VALIDASI: CEK STATUS =====
        $statusLower = strtolower($pesanan['status_pesanan']);
        if ($statusLower !== 'sudah dibayar') {
            return redirect()->to('/pesanan/detail/' . $pesanan_id)->with('error', 'PDF hanya tersedia untuk pesanan yang sudah diverifikasi.');
        }

        // Generate HTML untuk PDF
        $html = $this->generateStukHTML($pesanan);

        // Generate PDF menggunakan Dompdf
        try {
            $dompdf = new \Dompdf\Dompdf();
            $dompdf->loadHtml($html);
            $dompdf->setPaper('A4', 'portrait');
            $dompdf->render();

            // Output PDF
            $filename = 'Struk_Pesanan_' . $pesanan['id_pesanan'] . '_' . date('Y-m-d-H-i-s') . '.pdf';
            $dompdf->stream($filename);
            return;
        } catch (\Exception $e) {
            return redirect()->to('/pesanan/struk/' . $pesanan_id)->with('error', 'Gagal generate PDF: ' . $e->getMessage());
        }
    }

    /**
     * Generate HTML untuk PDF struk pembayaran
     * 
     * @param array $pesanan Data pesanan
     * @return string HTML content
     */
    private function generateStukHTML($pesanan)
    {
        // Hitung ulang subtotal
        $subtotal = 0;
        $menuItems = json_decode($pesanan['menu_pesanan'], true);
        if (is_array($menuItems)):
            foreach ($menuItems as $item):
                $subtotal += $item['price'] * $item['quantity'];
            endforeach;
        endif;

        $serviceFee = round($subtotal * 0.02);
        $tax = round($subtotal * 0.10);
        $total = $subtotal + $serviceFee + $tax;

        // Build HTML
        $html = '
        <!DOCTYPE html>
        <html lang="id">
        <head>
            <meta charset="UTF-8">
            <title>Struk Pembayaran</title>
            <style>
                body {
                    font-family: Arial, sans-serif;
                    margin: 0;
                    padding: 20px;
                    color: #333;
                }
                .struk-container {
                    max-width: 600px;
                    margin: 0 auto;
                    border: 1px solid #999;
                    padding: 20px;
                    background-color: #fff;
                }
                .struk-header {
                    text-align: center;
                    margin-bottom: 20px;
                    border-bottom: 2px solid #333;
                    padding-bottom: 15px;
                }
                .struk-header h1 {
                    margin: 0;
                    font-size: 24px;
                    color: #333;
                }
                .struk-header p {
                    margin: 5px 0 0 0;
                    font-size: 12px;
                    color: #666;
                }
                .struk-status {
                    background-color: #f0f0f0;
                    border: 1px solid #ddd;
                    padding: 10px;
                    text-align: center;
                    font-weight: bold;
                    margin-bottom: 20px;
                    color: #28a745;
                }
                .struk-section {
                    margin-bottom: 15px;
                }
                .struk-section-title {
                    font-weight: bold;
                    border-bottom: 1px solid #ddd;
                    padding-bottom: 5px;
                    margin-bottom: 10px;
                    font-size: 12px;
                    color: #333;
                }
                .struk-row {
                    display: flex;
                    justify-content: space-between;
                    padding: 5px 0;
                    font-size: 12px;
                    border-bottom: 1px dotted #ddd;
                }
                .struk-row:last-child {
                    border-bottom: none;
                }
                .menu-item {
                    display: flex;
                    justify-content: space-between;
                    padding: 5px 0;
                    font-size: 12px;
                    border-bottom: 1px dotted #ddd;
                }
                .struk-total {
                    background-color: #f9f9f9;
                    border: 1px solid #ddd;
                    padding: 10px;
                    margin: 15px 0;
                    border-radius: 4px;
                }
                .struk-total-row {
                    display: flex;
                    justify-content: space-between;
                    padding: 5px 0;
                    font-size: 12px;
                }
                .struk-total-row.final {
                    font-weight: bold;
                    font-size: 14px;
                    border-top: 1px solid #ddd;
                    padding-top: 8px;
                }
                .struk-footer {
                    text-align: center;
                    margin-top: 20px;
                    padding-top: 15px;
                    border-top: 1px solid #ddd;
                    font-size: 11px;
                    color: #666;
                }
                table {
                    width: 100%;
                    border-collapse: collapse;
                    font-size: 12px;
                    margin: 10px 0;
                }
                table th {
                    text-align: left;
                    padding: 5px;
                    border-bottom: 1px solid #ddd;
                    font-weight: bold;
                }
                table td {
                    padding: 5px;
                    border-bottom: 1px dotted #ddd;
                }
                .text-right {
                    text-align: right;
                }
            </style>
        </head>
        <body>
        <div class="struk-container">
            <!-- HEADER -->
            <div class="struk-header">
                <h1>STRUK PEMBAYARAN</h1>
                <p>Pesanan Anda Telah Diverifikasi</p>
            </div>

            <!-- STATUS -->
            <div class="struk-status">
                ✓ PEMBAYARAN TELAH DISETUJUI
            </div>

            <!-- NOMOR PESANAN -->
            <div class="struk-section">
                <div class="struk-section-title">Informasi Pesanan</div>
                <div class="struk-row">
                    <span><strong>No. Pesanan:</strong></span>
                    <span><strong>#' . $pesanan['id_pesanan'] . '</strong></span>
                </div>
                <div class="struk-row">
                    <span>Tanggal Pesan:</span>
                    <span>' . date('d-m-Y H:i', strtotime($pesanan['tanggal_pesan'])) . '</span>
                </div>
                <div class="struk-row">
                    <span>Tanggal Verifikasi:</span>
                    <span>' . date('d-m-Y H:i') . '</span>
                </div>
                <div class="struk-row">
                    <span>Status:</span>
                    <span><strong style="color: #28a745;">Sudah Dibayar ✓</strong></span>
                </div>
            </div>

            <!-- DATA PEMESAN -->
            <div class="struk-section">
                <div class="struk-section-title">Data Pemesan</div>
                <div class="struk-row">
                    <span>Nama:</span>
                    <span>' . $pesanan['nama_pemesan'] . '</span>
                </div>
                <div class="struk-row">
                    <span>No. Telepon:</span>
                    <span>' . $pesanan['nomor_hp'] . '</span>
                </div>
                <div class="struk-row">
                    <span>Tempat Kuliner:</span>
                    <span>' . $pesanan['nama_tempat'] . '</span>
                </div>
            </div>

            <!-- DETAIL MENU -->
            <div class="struk-section">
                <div class="struk-section-title">Detail Menu</div>
                <table>
                    <thead>
                        <tr>
                            <th>Menu</th>
                            <th>Qty</th>
                            <th class="text-right">Harga</th>
                            <th class="text-right">Subtotal</th>
                        </tr>
                    </thead>
                    <tbody>';

        if (is_array($menuItems)):
            foreach ($menuItems as $item):
                $html .= '<tr>
                            <td>' . $item['name'] . '</td>
                            <td>' . $item['quantity'] . '</td>
                            <td class="text-right">Rp ' . number_format($item['price'], 0, ',', '.') . '</td>
                            <td class="text-right">Rp ' . number_format($item['price'] * $item['quantity'], 0, ',', '.') . '</td>
                          </tr>';
            endforeach;
        endif;

        $html .= '
                    </tbody>
                </table>
            </div>

            <!-- RINGKASAN -->
            <div class="struk-total">
                <div class="struk-total-row">
                    <span>Subtotal:</span>
                    <span>Rp ' . number_format($subtotal, 0, ',', '.') . '</span>
                </div>
                <div class="struk-total-row">
                    <span>Service Fee (2%):</span>
                    <span>Rp ' . number_format($serviceFee, 0, ',', '.') . '</span>
                </div>
                <div class="struk-total-row">
                    <span>Pajak (10%):</span>
                    <span>Rp ' . number_format($tax, 0, ',', '.') . '</span>
                </div>
                <div class="struk-total-row final">
                    <span>TOTAL PEMBAYARAN:</span>
                    <span>Rp ' . number_format($pesanan['harga_perkiraan'], 0, ',', '.') . '</span>
                </div>
            </div>

            <!-- METODE PEMBAYARAN -->
            <div class="struk-section">
                <div class="struk-section-title">Metode Pembayaran</div>
                <div class="struk-row">
                    <span>Metode:</span>
                    <span><strong>' . $pesanan['metode_pembayaran'] . '</strong></span>
                </div>';

        if (strtolower($pesanan['metode_pembayaran']) === 'transfer bank'):
            $html .= '<div class="struk-row">
                    <span>Bank:</span>
                    <span>BRI</span>
                </div>
                <div class="struk-row">
                    <span>No. Rekening:</span>
                    <span>3406 0100 3344 503</span>
                </div>
                <div class="struk-row">
                    <span>Bukti:</span>
                    <span><strong style="color: #28a745;">✓ Terverifikasi</strong></span>
                </div>';
        endif;

        $html .= '
            </div>

            <!-- FOOTER -->
            <div class="struk-footer">
                <p>Terima kasih telah memesan di Kuliner Kampus</p>
                <p>Pesanan Anda telah diverifikasi dan siap dikerjakan</p>
                <p style="margin-top: 10px;">Struk ini dibuat pada ' . date('d-m-Y H:i:s') . '</p>
            </div>
        </div>
        </body>
        </html>
        ';

        return $html;
    }
}